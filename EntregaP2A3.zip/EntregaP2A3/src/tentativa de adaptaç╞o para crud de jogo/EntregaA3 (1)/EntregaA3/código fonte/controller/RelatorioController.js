// ▪ Geração de relatório de produtos mais vendido.
// ▪ Geração de relatório de produto por cliente.
// ▪ Geração de relatório de consumo médio do cliente.
// ▪ Geração de relatório de produto com baixo estoque.


const { Op } = require("sequelize");
const {VendaRepository,EstoqueRepository,ClientRepository,sequelize} = require("../model");

class RelatorioController{
    async produtosMaisVendidos(req, res) {
        try{
        const produto =  await VendaRepository.findAll({
                attributes: ['idEstoque', [sequelize.fn('count', sequelize.col('VendaRepository.idEstoque')), 'count_estoque']],
                group: [sequelize.col('VendaRepository.idEstoque')],
                order: [[sequelize.fn('count', sequelize.col('VendaRepository.idEstoque')), 'DESC']],
                include: [{
                    model: EstoqueRepository,
                    
                    as: "Estoque"
                  }]
          })
          res.json(produto);
        }catch(error)
        {
          return res.status(error.status||422 ).json(error)
        }
      }
      async mediaProduto(req, res) {
        try{
        const produto =  await VendaRepository.findAll({
                attributes: ['idCliente',[sequelize.fn('count', sequelize.col('VendaRepository.idEstoque')), 'count_estoque'],[sequelize.fn('AVG', sequelize.col('VendaRepository.preco')), 'media']],
                group: [sequelize.col('VendaRepository.idCliente')],
                order: [[sequelize.fn('AVG', sequelize.col('VendaRepository.preco')), 'DESC']],
                include: [
                  {
                    model: ClientRepository,
                    as: "Cliente"
                  }]
          })
          res.json(produto);
        }catch(error)
        {
          return res.status(error.status||422 ).json(error)
        }
      }
      
      async produtosBaixoEstoque(req, res) {
        try{
        const produto =  await EstoqueRepository.findAll({
                where:{
                    quantidade:{
                        [Op.lte]:sequelize.col('EstoqueRepository.limiteEstoque')
                    }
                }
          })
          res.json(produto);
        }catch(error)
        {
          return res.status(error.status||422 ).json(error)
        }
      }
      async produtoMaisVendidoCliente(req, res) {
        try{
            const produtos =  await VendaRepository.findAll({
                attributes: ['idCliente','idEstoque',[sequelize.fn('count', sequelize.col('VendaRepository.idEstoque')), 'count_estoque']],
                group: [sequelize.col('VendaRepository.idCliente'),sequelize.col('VendaRepository.idEstoque')],
                order: ['idCliente',[sequelize.fn('count', sequelize.col('VendaRepository.idEstoque')), 'DESC']],
                include: [
                  {
                    model: ClientRepository,
                    as: "Cliente"
                  },{
                    model: EstoqueRepository,
                    
                    as: "Estoque"
                  }]
          })
          const maior = []
          const produtoFiltro = await Promise.all(produtos.filter((produto) => {
            if(maior.includes(produto.idCliente)){
                return false
            }else{
                maior.push(produto.idCliente)
                return true
            }
          }))
          res.json(produtoFiltro);
        }catch(error)
        {
          return res.status(error.status||422 ).json(error)
        }
      }
}

module.exports = new RelatorioController();