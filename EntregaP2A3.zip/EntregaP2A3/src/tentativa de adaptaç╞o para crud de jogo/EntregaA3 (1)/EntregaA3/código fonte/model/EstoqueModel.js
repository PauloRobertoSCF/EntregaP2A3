// const { Sequelize } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    console.log(sequelize)
    const Estoque = sequelize.define("EstoqueRepository", {
      idEstoque: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      nome: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      quantidade: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
      },
      preco: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
      },
      limiteEstoque: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue:10
      },
      descricao: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },{
      tableName: 'estoque'
    })
    Estoque.associate = (models) => {
      Estoque.hasOne(models.VendaRepository, {
        foreignKey: 'idEstoque',
        as: 'Venda'
      })
    }
    return Estoque
   };