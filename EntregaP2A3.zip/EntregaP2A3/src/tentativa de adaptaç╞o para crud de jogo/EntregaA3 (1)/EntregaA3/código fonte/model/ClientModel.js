// const { Sequelize } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  console.log(sequelize)
  const Cliente = sequelize.define("ClientRepository", {
    idCliente: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    nome: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
  },{
    tableName: 'cliente'
  })
  Cliente.associate = (models) => {
    Cliente.hasOne(models.VendaRepository, {
      foreignKey: 'idCliente',
      as: 'Venda'
    })
  }


  return Cliente
 };

 