const cors = require("cors");
const express = require ("express");
// conexão com o banco de dados
const db = require ("./model");
const routes = require ("./routes.js");

// Importa os modelos necessários
const {ClientRepository,EstoqueRepository} = require("./model");


// Sincroniza o model com o banco de dados
db.sequelize.sync({
    force: true, // Use force: true apenas durante o desenvolvimento para recriar o banco de dados
  }).then(async () => {
    if(await ClientRepository.count() <5)
    {
        // Adiciona clientes pré-registrados
        await ClientRepository.bulkCreate([
          { nome: "Steam", email: "Steam@Steam.COM" },
          { nome: "EpicGames", email: "EpicGames@EpicGames.COM" },
          { nome: "Battle.net", email: "Battle.net@Battle.net.COM" },
          { nome: "GOG Games", email: "GOGGames@GOGGames.COM" },
          { nome: "Amazon Games", email: "AmazonGames@AmazonGames.COM" },
        ]);
    }
  
    if(await EstoqueRepository.count() <10)
    {
        // Adiciona produtos pré-registrados
        await EstoqueRepository.bulkCreate([
            { nome: "jogado", quantidade: 5, preco: 50, descricao: "a" },
            { nome: "jogando", quantidade: 5, preco: 100, descricao: "b" },
            { nome: "zerado", quantidade: 5, preco: 150, descricao: "c" },
            { nome: "não recomendo", quantidade: 10, preco: 200, descricao: "d" },
            { nome: "recomendo", quantidade: 15, preco: 250 , descricao: "e"},
            { nome: "Quero jogar", quantidade: 15, preco: 300 , descricao: "f"},
            { nome: "Terminar Depois", quantidade: 15, preco: 350 , descricao: "g"},
            { nome: "Apagar", quantidade: 15, preco: 400 , descricao: "h"},
            { nome: "Platinado", quantidade: 15, preco: 450 , descricao: "i"},
            { nome: "Favoritos", quantidade: 15, preco: 500 , descricao: "j"},
        ]);
    }
        
        console.info(`Banco de dados preenchido`);   
    });

// instancia o servidor Express
const app = express();

//configura o uso da resposta em formato json
app.use(express.json());

app.use(cors({
    origin: "*"
}));

//configura as rotas
app.use(routes);

// inicializa o express na porta 3000
app.listen(3000, () => console.log("Servidor iniciado em http://127.0.0.1:3000"));

///////////////////////////////////////////////////////////////
