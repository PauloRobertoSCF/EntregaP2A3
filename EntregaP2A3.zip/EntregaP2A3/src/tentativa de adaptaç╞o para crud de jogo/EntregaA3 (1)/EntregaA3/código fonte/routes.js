const express = require ("express");
const ClienteController = require ("./controller/ClienteController");
const EstoqueController = require ("./controller/EstoqueController");
const VendaController = require ("./controller/VendaController");
const RelatorioController = require ("./controller/RelatorioController");

const routes = express.Router();

routes.get("/", (req, res) => {
  return res.json({ name: "Ciclano Fulano" });
});

routes.get("/clientes", (req, res) => {
    return ClienteController.findAll(req,res);
  });
routes.post("/clientes", (req, res) => {
return ClienteController.create(req,res);
});
routes.put("/clientes", (req, res) => {
return ClienteController.update(req,res);
});
routes.delete("/clientes/:idCliente", (req, res) => {
return ClienteController.delete(req,res);
});

////////////////////////////////////////////////

routes.get("/estoques", (req, res) => {
  return EstoqueController.findAll(req,res);
});
routes.post("/estoques", (req, res) => {
return EstoqueController.create(req,res);
});
routes.put("/estoques", (req, res) => {
return EstoqueController.update(req,res);
});
routes.delete("/estoques/:idEstoque", (req, res) => {
return EstoqueController.delete(req,res);
});

////////////////////////////////////////////////

routes.get("/vendas", (req, res) => {
  return VendaController.findAll(req,res);
});
routes.post("/vendas", (req, res) => {
return VendaController.create(req,res);
});
routes.put("/vendas", (req, res) => {
return VendaController.update(req,res);
});
routes.delete("/vendas/:idVenda", (req, res) => {
return VendaController.delete(req,res);
});

////////////////////////////////////////////////

routes.get("/relatorios/produtosMaisVendidos", (req, res) => {
  return RelatorioController.produtosMaisVendidos(req,res);
});

routes.get("/relatorios/produtosBaixoEstoque", (req, res) => {
  return RelatorioController.produtosBaixoEstoque(req,res);
});

routes.get("/relatorios/mediaProduto", (req, res) => {
  return RelatorioController.mediaProduto(req,res);
});

routes.get("/relatorios/produtoMaisVendidoCliente", (req, res) => {
  return RelatorioController.produtoMaisVendidoCliente(req,res);
});

module.exports=routes;